
import { FusionChartStatic } from 'fusioncharts';

declare namespace Gantt {}
declare var Gantt: (H: FusionChartStatic) => FusionChartStatic;
export = Gantt;
export as namespace Gantt;

