
import { FusionChartStatic } from 'fusioncharts';

declare namespace Msstackedcolumn2dsplinedy {}
declare var Msstackedcolumn2dsplinedy: (H: FusionChartStatic) => FusionChartStatic;
export = Msstackedcolumn2dsplinedy;
export as namespace Msstackedcolumn2dsplinedy;

