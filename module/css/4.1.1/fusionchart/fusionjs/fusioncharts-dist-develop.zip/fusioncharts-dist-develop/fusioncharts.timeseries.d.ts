
import { FusionChartStatic } from 'fusioncharts';

declare namespace Timeseries {}
declare var Timeseries: (H: FusionChartStatic) => FusionChartStatic;
export = Timeseries;
export as namespace Timeseries;

