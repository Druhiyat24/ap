
import { FusionChartStatic } from 'fusioncharts';

declare namespace Usa {}
declare var Usa: (H: FusionChartStatic) => FusionChartStatic;
export = Usa;
export as namespace Usa;

