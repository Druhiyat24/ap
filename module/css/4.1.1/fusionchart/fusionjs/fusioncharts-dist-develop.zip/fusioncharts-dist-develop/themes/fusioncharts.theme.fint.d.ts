
import { FusionChartStatic } from 'fusioncharts';

declare namespace Fint {}
declare var Fint: (H: FusionChartStatic) => FusionChartStatic;
export = Fint;
export as namespace Fint;

